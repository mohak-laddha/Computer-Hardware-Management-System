package myPackage;

public class MyClass
{	
	public void project_name()
	{
		System.out.println("Welcome to Computer Hardware Management System");
	}
	
}